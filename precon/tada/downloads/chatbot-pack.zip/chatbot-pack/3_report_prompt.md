# Report Prompt — paste this after the primer and your CSV.

Using ONLY the context primer and the CSV I gave you, produce a clear, classroom-ready
report with these sections. Ask me nothing first; just produce it from the data.

1. ITEM ANALYSIS
   A short table: each question, the phase it measures, and the % of students who got it
   correct. Flag any item below 50% as a class-wide gap.

2. WHERE EACH STUDENT IS
   A table: student ID, their phase of learning (Surface / Deep / Transfer / Emerging),
   and a one-line reason from their answer pattern.

3. THE CLASS AT A GLANCE
   How many students are in each phase, and what that says about the class as a whole.

4. WHAT TO DO NEXT
   For each phase group present in the data, give:
     - the ACE next step (Articulate / Connect / Extend),
     - ONE high-effect-size strategy that fits that phase (name it with its effect size),
     - one concrete thing to do in the next lesson.

5. TOMORROW
   Two or three sentences: the single most important move for this class, based on where
   most students are.

Keep it concise and practical. Use plain language a busy teacher can act on. Do not
invent any numbers or studies; if the data doesn't show something, say so.
