# Supportive Prompts — copy any of these as a follow-up after you get your report.

## Go deeper on one group
"Focus on my Surface-phase students. Give me a 15-minute Articulate-It mini-lesson I could
run tomorrow for that group, tied to this content."

## Plan the differentiation
"Turn the report into three parallel tasks for the same lesson — one for each phase group —
so every student works at the right level on the same topic."

## Make a parent-friendly summary
"Write a short, warm note I could send families explaining what this assessment showed and
what we'll work on next. No jargon, no student names."

## Check a single student
"Look only at student S04. Walk me through their answer pattern and tell me the one barrier
most likely holding them back from the next phase."

## Build the next assessment
"Design a 5-question post-assessment on this same topic that would show me whether students
moved up a phase. Label each question by phase and SOLO level."

## Pressure-test the analysis
"Audit your own report: recompute one question's percentage from my CSV to prove it's right,
and confirm no Transfer strategy was recommended for a group still at Surface. List anything
you correct."

## Turn it into a small-group rotation
"Give me a 3-station rotation for a 45-minute block based on these phase groups, with what
each station does and which students go where."
