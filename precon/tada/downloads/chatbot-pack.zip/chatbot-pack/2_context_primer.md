# Context Primer — attach this FIRST. The AI must use ONLY what's here; no invented numbers.

## Phases of learning (John Hattie, Visible Learning)
- Surface: facts, vocabulary, basic skills. (SOLO: Unistructural, Multistructural)
- Deep: connecting ideas and explaining how they fit. (SOLO: Relational)
- Transfer: applying learning to a new, unfamiliar situation. (SOLO: Extended Abstract)
Principle: "What and when are equally important." Match the teaching move to the phase.

## SOLO levels
Pre-structural (misses the point) -> Unistructural (one idea) -> Multistructural (several
unconnected ideas) -> Relational (ideas connected into a whole) -> Extended Abstract
(generalizes to new situations).

## ACE next steps (what to do next, built on SOLO)
- Articulate It: state/name knowledge clearly. For Surface learners.
- Connect It: link ideas together. For moving Surface -> Deep.
- Extend It: apply to new contexts. For moving Deep -> Transfer.

## High-effect-size strategies (effect size >= 0.40 accelerates learning)
Jigsaw 0.92 (Surface+Deep) · Argumentation 0.86 (Deep) · Outlining/Organizing 0.85 (Deep)
· Critical Thinking 0.79 (Deep/Transfer) · Transfer Strategies 0.75 (Transfer)
· Reciprocal Teaching 0.74 (Deep) · Concept Mapping 0.66 (Deep) · Vocabulary 0.62 (Surface)
· Problem-Solving Teaching 0.61 (Transfer).
Timing rule: Transfer strategies only work AFTER Surface and Deep are solid.

## Reading the CSV
Each row is a student (S01, S02...). Each question column ends in the phase it measures
(_surface, _deep, _transfer) and holds 1 (correct) or 0 (not yet).
- A student correct mainly on surface items = Surface.
- Correct on surface AND deep items = Deep.
- Correct on surface, deep, AND transfer = Transfer.
- Surface items not yet secure = Emerging (needs foundational support first).
When a pattern is mixed, name the highest phase the student CONSISTENTLY shows and note
the barrier to the next phase.

## Don't
Invent effect sizes or studies. Recommend a Transfer strategy to a Surface group.
Give generic advice that ignores the actual data.
