# Pedagogy Showcase Interest Poll

A three part system for TCEA Professional Development.

- `index.html` is the public poll, twelve required questions, about two minutes.
- `results.html` is the password protected dashboard, password `CHANGE-ME`.
- `Code.gs` is a standalone Google Apps Script that creates its own Google Sheet and moves data between the two pages.

**Start here.** Read `SETUP.md` for deployment in six steps. Read `HANDOFF.md` for build context, design decisions, and the field contract before you change anything.

Nothing needs installing. Both HTML files are self contained, use vanilla JavaScript, and run from GitHub Pages.
