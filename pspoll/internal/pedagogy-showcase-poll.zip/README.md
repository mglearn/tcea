# Pedagogy Showcase Interest Poll

A three part system for TCEA Professional Development.

- `index.html` is the public poll, twelve required questions, about two minutes.
- `results.html` is the password protected dashboard, password `CHANGE-ME`.
- `results2.html` is the same dashboard filled with twenty invented respondents, no password, so you can show people the output before real answers arrive.
- `Code.gs` is a standalone Google Apps Script that creates its own Google Sheet and moves data between the two pages.

**Start here.** Read `SETUP.md` for deployment in six steps. Read `HANDOFF.md` for build context, design decisions, and the field contract before you change anything.

Nothing needs installing. Both HTML files are self contained, use vanilla JavaScript, and run from GitHub Pages.

**Layout note.** Everything in this bundle is flat, so the commands in `SETUP.md` and `HANDOFF.md` work as written. In the git repository the three HTML files live in `pspoll/` and the rest live in `pspoll/internal/`, which the deploy workflow keeps off the website. That folder is not private, only unpublished. The repository is public.
