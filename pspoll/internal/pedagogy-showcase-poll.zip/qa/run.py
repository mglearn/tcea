import subprocess, time, sys
import os
QA_DIR = os.path.dirname(os.path.abspath(__file__))  # was a hardcoded /home/claude/qa

srv = subprocess.Popen([sys.executable,"-m","http.server","8099"], cwd=QA_DIR,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(2)
from playwright.sync_api import sync_playwright
errs=[]
try:
    with sync_playwright() as p:
        b=p.chromium.launch()
        pg=b.new_page(viewport={"width":1100,"height":900})
        pg.on("console", lambda m: errs.append(("poll",m.type,m.text)) if m.type=="error" else None)
        pg.on("pageerror", lambda e: errs.append(("poll","pageerror",str(e))))
        pg.goto("http://localhost:8099/poll.html"); pg.wait_for_timeout(1200)
        pg.screenshot(path=os.path.join(QA_DIR, "poll_desktop.png"), full_page=True)
        pg.click("text=Instructional coach or specialist")
        pg.click("text=3 to 5")
        labels=pg.query_selector_all('#q-topics_top3 label.opt')
        for l in labels[:4]:
            l.click(); pg.wait_for_timeout(120)
        print("counter after 4 clicks:", pg.inner_text("#cnt-topics_top3"))
        print("checked:", [l.get_attribute("data-v") for l in labels if l.query_selector("input").is_checked()])
        print("progress:", pg.inner_text("#plabel"))
        pg.click("#submitBtn"); pg.wait_for_timeout(400)
        print("validation:", pg.inner_text("#formMsg")[:100])
        pg.screenshot(path=os.path.join(QA_DIR, "poll_validation.png"), full_page=True)
        m=b.new_page(viewport={"width":390,"height":844})
        m.goto("http://localhost:8099/poll.html"); m.wait_for_timeout(1000)
        m.screenshot(path=os.path.join(QA_DIR, "poll_mobile.png"), full_page=True)

        r=b.new_page(viewport={"width":1100,"height":900})
        r.on("console", lambda mm: errs.append(("report",mm.type,mm.text)) if mm.type=="error" else None)
        r.on("pageerror", lambda e: errs.append(("report","pageerror",str(e))))
        r.goto("http://localhost:8099/report.html"); r.wait_for_timeout(700)
        r.fill("#pw","CHANGE-ME"); r.click("#go"); r.wait_for_timeout(1800)
        print("report visible:", r.is_visible("#report"))
        print("stamp:", r.inner_text("#stamp"))
        print("kpis:", r.inner_text("#kpis").replace("\n"," | "))
        print("INSIGHTS:\n", r.inner_text("#insights"))
        print("MATCHUPS:\n", r.inner_text("#matchups")[:800])
        print("FREETEXT:\n", r.inner_text("#freetext")[:400])
        print("XTAB:\n", r.inner_text("#x-satrole")[:400])
        r.screenshot(path=os.path.join(QA_DIR, "report_desktop.png"), full_page=True)
        rm=b.new_page(viewport={"width":390,"height":844})
        rm.goto("http://localhost:8099/report.html"); rm.wait_for_timeout(600)
        rm.fill("#pw","CHANGE-ME"); rm.click("#go"); rm.wait_for_timeout(1500)
        rm.screenshot(path=os.path.join(QA_DIR, "report_mobile.png"), full_page=True)
        b.close()
finally:
    srv.terminate()
print("ERRORS:", errs)
