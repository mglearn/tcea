# How to Use This RAG Support Pack

This zip file contains source files for the AI Design Companion website and chatbot/RAG setup.

## What is included

- Markdown source files for the main frameworks and companion workflow
- A JSON knowledge pack for systems that prefer structured data
- Project instructions for configuring a chatbot assistant
- Plain-text copies of every source file for platforms that struggle with Markdown or JSON
- One combined plain-text file containing all RAG source content

## Recommended setup

### Option 1: Custom GPT / Claude Project / Gemini Gem

1. Upload all files in the `rag-support/` folder.
2. Paste the contents of `11_project_instructions.md` into the project/system instructions field.
3. Tell the chatbot to answer from the uploaded files first.
4. Ask users to paste exact TEKS expectations when TEKS-level accuracy is needed.

### Option 2: NotebookLM / Gemini with Google Drive sources

1. Place the source files in a Google Drive folder.
2. Add them as NotebookLM sources.
3. Keep source files updated in Drive.
4. Use the project instructions as the notebook guide or custom instruction text.

### Option 3: Plain-text fallback

If the receiving chatbot cannot read Markdown or JSON reliably, upload the files in the `plain-text/` folder instead.

Use `ALL_RAG_FILES_PLAIN_TEXT.txt` when the chatbot allows only one source file.

## Important use notes

- Do not let the chatbot invent TEKS codes or student expectations.
- Do not let the chatbot invent effect sizes.
- Ask users to attach or paste the exact TEKS and source materials when precision matters.
- Use ALDO as a conversation sequence, not a generic lesson-plan template.
- Use SOLO and Visible Learning to audit depth and strategy timing.
- Avoid student personally identifiable information.

## Suggested first chatbot instruction

Use the attached files as your knowledge base. Act as an instructional design partner. Use ALDO, SOLO Taxonomy, Visible Learning phases, TEKS-aware prompting, and the audit checklist. If the source files do not support a claim, say so and ask for the missing source.
