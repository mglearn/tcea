# AI Design Companion RAG Support Pack Manifest
## Source files
- rag-support/00_readme.md
- rag-support/01_session_overview.md
- rag-support/02_aldo_framework.md
- rag-support/03_solo_taxonomy.md
- rag-support/04_visible_learning_strategy_source.md
- rag-support/05_audit_checklist.md
- rag-support/06_prompt_pack.md
- rag-support/07_activity_facilitator_notes.md
- rag-support/08_ace_curriculum_source.md
- rag-support/09_role_differentiation_cards.md
- rag-support/10_json_knowledge_pack.json
- rag-support/11_project_instructions.md
- rag-support/README_USE_THESE_FILES.md

## Plain-text fallback files
- plain-text/00_readme.txt
- plain-text/01_session_overview.txt
- plain-text/02_aldo_framework.txt
- plain-text/03_solo_taxonomy.txt
- plain-text/04_visible_learning_strategy_source.txt
- plain-text/05_audit_checklist.txt
- plain-text/06_prompt_pack.txt
- plain-text/07_activity_facilitator_notes.txt
- plain-text/08_ace_curriculum_source.txt
- plain-text/09_role_differentiation_cards.txt
- plain-text/10_json_knowledge_pack.txt
- plain-text/11_project_instructions.txt
- plain-text/ALL_RAG_FILES_PLAIN_TEXT.txt
- plain-text/README_USE_THESE_FILES.txt
