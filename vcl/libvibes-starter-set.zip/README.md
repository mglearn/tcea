# LibVibes Starter Set — Built Examples

Three ready-to-host library tools, vibe-coded from the LibVibes prompts. Each folder is a
complete, dependency-free app: open `index.html` in a browser, host it on GitHub Pages, or
embed it in Google Sites. Each folder has its own `SETUP.md`.

| Folder | Tool | LibVibes Prompt | Level |
|--------|------|-----------------|-------|
| `callnumber-game/` | Shelve It Right! (Dewey & fiction shelf-order game) | #6 | Beginner |
| `boolean-trainer/` | Boolean Search Trainer (AND/OR/NOT practice) | #13 | Intermediate |
| `mock-award/` | Mock Caldecott voting station (front-end demo) | #17 | Advanced |

Want the rest? The full set of 18 prompts lives on the **LibVibes** page. Paste any one into
ChatGPT, Claude, Gemini, or BoodleBox and iterate with the VIBES framework.

— Companion to "Vibe Your Way to Free" · TCEA
