# Mock Caldecott Award — Voting Station

A LibVibes built example (Prompt #17). A nominee gallery, a ballot, and live animated
results with a winner's crown — for running a student book-award vote.

## What's in this zip
- `index.html` — the entire demo. One file, no dependencies, works offline.

## Important: this is the front-end demo
This single file saves votes **in the browser on each device** (localStorage), which is perfect
for trying the full flow on one screen or as a kiosk. To collect votes from a whole class on
many devices and keep the data, build the **Google Sheets–backed version**: copy Prompt #17 from
the LibVibes page into your AI assistant. That version stores every ballot in a Sheet you own and
adds a password-protected admin page.

## Run the demo (pick one)
1. **Just open it.** Double-click `index.html` — it runs in any browser.
2. **Host on GitHub Pages** or **embed in Google Sites** (Insert → Embed → By URL).

## Make it yours
Open `index.html` and edit the block marked `/* ===== EDIT ME: nominees & classes ===== */`:
- `NOMINEES` — your shortlisted books (title, author, blurb, an emoji or color).
- `CLASSES` — your class or homeroom names.

The **Admin** tab can open/close voting, clear votes, and reset a device for re-testing.

— Companion to "Vibe Your Way to Free" · TCEA · LibVibes
