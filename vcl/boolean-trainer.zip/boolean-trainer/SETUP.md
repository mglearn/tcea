# Boolean Search Trainer

A LibVibes built example (Prompt #13). A pretend database where **AND, OR, NOT, "quotes",
and ( )** change the results live, with challenges students solve to learn database searching.

## What's in this zip
- `index.html` — the entire app. One file, no dependencies, works offline.

## Run it (pick one)
1. **Just open it.** Double-click `index.html` — it runs in any browser.
2. **Host on GitHub Pages.** Create a repo, upload `index.html`, then turn on
   Settings → Pages → Deploy from branch (root). Your link appears in a minute.
3. **Embed in Google Sites.** Host it (step 2), then in Google Sites choose
   **Insert → Embed → By URL** and paste your GitHub Pages link.

## Make it yours
Open `index.html` in any text editor and edit the two blocks marked `/* ===== EDIT ME ... */`:
- `ARTICLES` — the fake article cards and their keyword tags.
- `CHALLENGES` — each task and the `target` list of article IDs a correct query should return.

Tip: pair this with a short screencast of *your* real databases so students transfer the skill.
Want changes? Paste `index.html` back into your AI assistant — that's the **B**uild step of VIBES.

— Companion to "Vibe Your Way to Free" · TCEA · LibVibes
