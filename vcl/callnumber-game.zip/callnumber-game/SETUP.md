# Shelve It Right! — Call Number Shelving Game

A LibVibes built example (Prompt #6). Students drag scrambled spine labels into correct
**Dewey** or **fiction** order; the game checks each spine, marks it, and explains the rule.

## What's in this zip
- `index.html` — the entire app. One file, no dependencies, works offline.

## Run it (pick one)
1. **Just open it.** Double-click `index.html` — it runs in any browser.
2. **Host on GitHub Pages.** Create a repo, upload `index.html`, then turn on
   Settings → Pages → Deploy from branch (root). Your link appears in a minute.
3. **Embed in Google Sites.** Host it (step 2), then in Google Sites choose
   **Insert → Embed → By URL** and paste your GitHub Pages link.

## Make it yours
Open `index.html` in any text editor and edit the block marked
`/* ===== EDIT ME: practice sets ===== */` near the top of the `<script>`:
- `SETS.dewey` — rows of call numbers from *your* nonfiction shelves.
- `SETS.fiction` — author last names from *your* fiction section.

Want changes (more spines, a timer, harder rounds)? Paste `index.html` back into your AI
assistant with the change you want — that's the **B**uild step of VIBES.

— Companion to "Vibe Your Way to Free" · TCEA · LibVibes
